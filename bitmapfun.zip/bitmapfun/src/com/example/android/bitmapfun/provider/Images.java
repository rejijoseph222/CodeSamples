/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.bitmapfun.provider;

import com.example.android.bitmapfun.util.ImageWorker.ImageWorkerAdapter;

/**
 * Some simple test data to use for this sample app.
 */
public class Images {

    /**
     * This are PicasaWeb URLs and could potentially change. Ideally the PicasaWeb API should be
     * used to fetch the URLs.
     */
    public final static String[] imageUrls = new String[] {
        "http://b123.in/test/data/Week/Isu10/10w01.jpg",
        "http://b123.in/test/data/Week/Isu10/10w02.jpg",
        "http://b123.in/test/data/Week/Isu10/10w03.jpg",
        "http://b123.in/test/data/Week/Isu10/10w04.jpg",
        "http://b123.in/test/data/Week/Isu10/10w05.jpg",
        "http://b123.in/test/data/Week/Isu10/10w06.jpg",
        "http://b123.in/test/data/Week/Isu10/10w07.jpg",
        "http://b123.in/test/data/Week/Isu10/10w08.jpg",
        "http://b123.in/test/data/Week/Isu10/10w09.jpg",
        "http://b123.in/test/data/Week/Isu10/10w10.jpg",
        "http://b123.in/test/data/Week/Isu10/10w11.jpg",
        "http://b123.in/test/data/Week/Isu10/10w12.jpg",
        "http://b123.in/test/data/Week/Isu10/10w13.jpg",
        "http://b123.in/test/data/Week/Isu10/10w14.jpg",
        "http://b123.in/test/data/Week/Isu10/10w15.jpg",
        "http://b123.in/test/data/Week/Isu10/10w16.jpg",
        "http://b123.in/test/data/Week/Isu10/10w17.jpg",
        "http://b123.in/test/data/Week/Isu10/10w18.jpg",
        "http://b123.in/test/data/Week/Isu10/10w19.jpg",
        "http://b123.in/test/data/Week/Isu10/10w20.jpg",
        "http://b123.in/test/data/Week/Isu10/10w21.jpg",
        "http://b123.in/test/data/Week/Isu10/10w22.jpg",
        "http://b123.in/test/data/Week/Isu10/10w23.jpg",
        "http://b123.in/test/data/Week/Isu10/10w24.jpg",
        "http://b123.in/test/data/Week/Isu10/10w25.jpg",
        "http://b123.in/test/data/Week/Isu10/10w26.jpg",
        "http://b123.in/test/data/Week/Isu10/10w27.jpg",
        "http://b123.in/test/data/Week/Isu10/10w28.jpg",
        "http://b123.in/test/data/Week/Isu10/10w29.jpg",
        "http://b123.in/test/data/Week/Isu10/10w30.jpg",
        "http://b123.in/test/data/Week/Isu10/10w31.jpg",
        "http://b123.in/test/data/Week/Isu10/10w32.jpg",
        "http://b123.in/test/data/Week/Isu10/10w33.jpg",
        "http://b123.in/test/data/Week/Isu10/10w34.jpg",
        "http://b123.in/test/data/Week/Isu10/10w35.jpg",
        "http://b123.in/test/data/Week/Isu10/10w36.jpg",
        "http://b123.in/test/data/Week/Isu10/10w37.jpg",
        "http://b123.in/test/data/Week/Isu10/10w38.jpg",
        "http://b123.in/test/data/Week/Isu10/10w39.jpg",
        "http://b123.in/test/data/Week/Isu10/10w40.jpg",
        "http://b123.in/test/data/Week/Isu10/10w41.jpg",
        "http://b123.in/test/data/Week/Isu10/10w42.jpg",
        "http://b123.in/test/data/Week/Isu10/10w43.jpg",
        "http://b123.in/test/data/Week/Isu10/10w44.jpg"
        
    };

    /**
     * This are PicasaWeb thumbnail URLs and could potentially change. Ideally the PicasaWeb API
     * should be used to fetch the URLs.
     */
    public final static String[] imageThumbUrls = new String[] {
    	 "http://b123.in/test/data/Week/Isu10/10w01.jpg",
         "http://b123.in/test/data/Week/Isu10/10w02.jpg",
         "http://b123.in/test/data/Week/Isu10/10w03.jpg",
         "http://b123.in/test/data/Week/Isu10/10w04.jpg",
         "http://b123.in/test/data/Week/Isu10/10w05.jpg",
         "http://b123.in/test/data/Week/Isu10/10w06.jpg",
         "http://b123.in/test/data/Week/Isu10/10w07.jpg",
         "http://b123.in/test/data/Week/Isu10/10w08.jpg",
         "http://b123.in/test/data/Week/Isu10/10w09.jpg",
         "http://b123.in/test/data/Week/Isu10/10w10.jpg",
         "http://b123.in/test/data/Week/Isu10/10w11.jpg",
         "http://b123.in/test/data/Week/Isu10/10w12.jpg",
         "http://b123.in/test/data/Week/Isu10/10w13.jpg",
         "http://b123.in/test/data/Week/Isu10/10w14.jpg",
         "http://b123.in/test/data/Week/Isu10/10w15.jpg",
         "http://b123.in/test/data/Week/Isu10/10w16.jpg",
         "http://b123.in/test/data/Week/Isu10/10w17.jpg",
         "http://b123.in/test/data/Week/Isu10/10w18.jpg",
         "http://b123.in/test/data/Week/Isu10/10w19.jpg",
         "http://b123.in/test/data/Week/Isu10/10w20.jpg",
         "http://b123.in/test/data/Week/Isu10/10w21.jpg",
         "http://b123.in/test/data/Week/Isu10/10w22.jpg",
         "http://b123.in/test/data/Week/Isu10/10w23.jpg",
         "http://b123.in/test/data/Week/Isu10/10w24.jpg",
         "http://b123.in/test/data/Week/Isu10/10w25.jpg",
         "http://b123.in/test/data/Week/Isu10/10w26.jpg",
         "http://b123.in/test/data/Week/Isu10/10w27.jpg",
         "http://b123.in/test/data/Week/Isu10/10w28.jpg",
         "http://b123.in/test/data/Week/Isu10/10w29.jpg",
         "http://b123.in/test/data/Week/Isu10/10w30.jpg",
         "http://b123.in/test/data/Week/Isu10/10w31.jpg",
         "http://b123.in/test/data/Week/Isu10/10w32.jpg",
         "http://b123.in/test/data/Week/Isu10/10w33.jpg",
         "http://b123.in/test/data/Week/Isu10/10w34.jpg",
         "http://b123.in/test/data/Week/Isu10/10w35.jpg",
         "http://b123.in/test/data/Week/Isu10/10w36.jpg",
         "http://b123.in/test/data/Week/Isu10/10w37.jpg",
         "http://b123.in/test/data/Week/Isu10/10w38.jpg",
         "http://b123.in/test/data/Week/Isu10/10w39.jpg",
         "http://b123.in/test/data/Week/Isu10/10w40.jpg",
         "http://b123.in/test/data/Week/Isu10/10w41.jpg",
         "http://b123.in/test/data/Week/Isu10/10w42.jpg",
         "http://b123.in/test/data/Week/Isu10/10w43.jpg",
         "http://b123.in/test/data/Week/Isu10/10w44.jpg"
    };

    /**
     * Simple static adapter to use for images.
     */
    public final static ImageWorkerAdapter imageWorkerUrlsAdapter = new ImageWorkerAdapter() {
        @Override
        public Object getItem(int num) {
            return Images.imageUrls[num];
        }

        @Override
        public int getSize() {
            return Images.imageUrls.length;
        }
    };

    /**
     * Simple static adapter to use for image thumbnails.
     */
    public final static ImageWorkerAdapter imageThumbWorkerUrlsAdapter = new ImageWorkerAdapter() {
        @Override
        public Object getItem(int num) {
            return Images.imageThumbUrls[num];
        }

        @Override
        public int getSize() {
            return Images.imageThumbUrls.length;
        }
    };
}
